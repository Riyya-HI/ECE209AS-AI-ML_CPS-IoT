
Video_1 - v1 Train_Vid_1
==============================

This dataset was exported via roboflow.ai on March 28, 2021 at 8:39 PM GMT

It includes 10 images.
Objects are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


