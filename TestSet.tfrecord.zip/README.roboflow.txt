
Limited_New - v1 V1_27March
==============================

This dataset was exported via roboflow.ai on March 27, 2021 at 7:34 AM GMT

It includes 5 images.
Objects are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


